<?php include "sidebar.php"; ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
					<div class="col-md-8 col-md-offset-2">
                        <div class="card">
                            <div class="header text-center">
                                <h4 class="title">Offence Detail</h4>
                                <p class="category">Are you looking for more components? Please check our Premium Version of Light Bootstrap Dashboard.</p>
								<br>
                            </div>
                            <div class="content table-responsive table-full-width table-upgrade">
                                <table class="table">
                                    <thead>
                                        <th></th>
                                    	<th class="text-center">Free</th>
                                    	<th class="text-center">PRO</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        	<td>Components</td>
                                        	<td>16</td>
                                        	<td>115+</td>
                                        </tr>
                           </div>
                </div>

            </div>
        </div>
		</div>
		</div>
	
<?php include "footer.php"; ?>